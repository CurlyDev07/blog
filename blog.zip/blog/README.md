# blog
unfinish blog site

in zip file there's a blog.SQL-Script file import it on the server
