

<pre>

    {{ $post->id }} <br>
    {{ $post->title }} <br>
    {{ $post->body }} <br>

</pre>