

<pre>

    <?php echo e($post->id); ?> <br>
    <?php echo e($post->title); ?> <br>
    <?php echo e($post->body); ?> <br>

</pre>