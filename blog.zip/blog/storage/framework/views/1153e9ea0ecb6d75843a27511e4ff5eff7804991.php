<?php $__env->startSection('content'); ?>
    <div class="col-md-8 blog-main">
        <h1>Publish a post</h1>
        <hr>
        <form method="POST" action="/posts">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="title">Title: </label>
                <input type="text" class="form-control" id="title" name="title" >
                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <div class="form-group">
                <label for="body">Body</label>
                <textarea name="body" id="body" class="form-control" ></textarea>
            </div>
        
            <button type="submit" class="btn btn-primary">Publish</button>
           
            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>