<?php

namespace App;

class Post extends Model
{
    public function comments(){
        return $this->hasMany(Comment::class); // this comment clas is the same with App/Comment
    }
}
