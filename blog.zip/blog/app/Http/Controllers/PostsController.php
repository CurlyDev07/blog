<?php

namespace App\Http\Controllers;
use App\Post;
use App\Comment;
use Illuminate\Http\Request;
class PostsController extends Controller
{
    public function index(){
        $post = Post::latest()->get();
        return view('posts/index', compact('post'));
    }

 
    public function show($id){
            $solo_post = Post::find($id);
        return view('posts/single_article', compact('solo_post'));
    }

    public function create(){
        return view('posts/create'); 
    }

    public function store(){

       $this->validate(request(), [
           'title' => 'required', 
           'body' => 'required'
       ]);

        Post::create(request(['title', 'body'])); // get the request and save it

       return redirect('/');

        // dd(request(['title', 'body'])); // get all the form request
        // create a new post using the request data
        // save it to the database
        // redirect to homepage
    }
}
