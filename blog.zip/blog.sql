-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 02, 2018 at 10:07 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `body` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `body`, `created_at`, `updated_at`) VALUES
(1, 2, 'very informative', NULL, NULL),
(2, 2, 'great article', NULL, NULL),
(3, 1, 'nice', NULL, NULL),
(7, 2, 'dasdsad', '2018-09-14 19:54:08', '2018-09-14 19:54:08'),
(8, 2, 'dsadas', '2018-09-14 19:54:11', '2018-09-14 19:54:11'),
(9, 2, 'dasds', '2018-09-14 19:54:13', '2018-09-14 19:54:13'),
(10, 2, 'dasdsad5564654dsads', '2018-09-14 19:54:17', '2018-09-14 19:54:17'),
(11, 2, 'dasd', '2018-09-14 19:54:27', '2018-09-14 19:54:27'),
(12, 1, 'good job', '2018-09-14 19:54:45', '2018-09-14 19:54:45'),
(13, 1, 'dasdsa', '2018-09-14 19:55:31', '2018-09-14 19:55:31'),
(14, 1, '432142345rqadas', '2018-09-14 19:55:36', '2018-09-14 19:55:36'),
(15, 1, 'comment', '2018-09-14 19:57:30', '2018-09-14 19:57:30'),
(16, 1, 'dasdsad', '2018-09-14 19:57:34', '2018-09-14 19:57:34'),
(17, 1, 'dasdsa', '2018-09-14 19:57:36', '2018-09-14 19:57:36'),
(18, 3, 'dasdsadsa', '2018-09-14 20:04:01', '2018-09-14 20:04:01'),
(19, 3, 'dasdasd', '2018-09-14 20:04:03', '2018-09-14 20:04:03'),
(20, 3, 'gdfgWETEWGS', '2018-09-14 20:04:05', '2018-09-14 20:04:05'),
(21, 3, 'hello', '2018-09-16 17:16:05', '2018-09-16 17:16:05'),
(22, 3, 'gdsfdsf', '2018-09-16 17:16:09', '2018-09-16 17:16:09'),
(23, 3, 'dasdsad', '2018-09-16 17:16:11', '2018-09-16 17:16:11'),
(24, 3, 'Greate Post', '2018-09-24 18:33:04', '2018-09-24 18:33:04'),
(25, 1, 'amen', '2018-09-24 18:35:58', '2018-09-24 18:35:58'),
(29, 4, 'dasd', '2018-09-24 21:40:18', '2018-09-24 21:40:18'),
(30, 4, 'no comment', '2018-09-24 21:40:30', '2018-09-24 21:40:30'),
(31, 4, 'hello', '2018-09-24 21:42:05', '2018-09-24 21:42:05'),
(32, 3, 'bago', '2018-09-24 21:42:55', '2018-09-24 21:42:55'),
(33, 5, 'hello!', '2018-09-24 21:46:26', '2018-09-24 21:46:26'),
(51, 5, 'hey!', '2018-09-24 22:11:11', '2018-09-24 22:11:11'),
(52, 5, 'hey once again.', '2018-09-24 22:11:37', '2018-09-24 22:11:37'),
(53, 6, 'Great keep it up. :)', '2018-09-24 22:12:13', '2018-09-24 22:12:13'),
(55, 6, 'nc!', '2018-09-24 22:17:59', '2018-09-24 22:17:59');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(13, '2014_10_12_000000_create_users_table', 1),
(14, '2014_10_12_100000_create_password_resets_table', 1),
(15, '2018_09_13_065806_create_posts_table', 1),
(16, '2018_09_14_064416_create_comments_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `created_at`, `updated_at`) VALUES
(1, 'WordAi Automatically Rewrites  Entire Sentences and Paragraphs', 'Unlike other spinners, WordAi fully understands what each word content means. It doesn\'t view sentences as just a list of words, it views them as real things that interact with each other. This human like understanding allows WordAI to automatically rewrite entire sentences from scratch. This high level of rewriting ensures that Google and Copyscape can\'t detect your content while still remaining human readable!\r\n\r\nOriginal Sentence: Nobody has been arrested by the police officers, but the suspect is being interrogated by them. \r\nAutomatic Rewrite: Law enforcement are interrogating the defendant, although they have not detained anybody.', '2018-09-14 18:33:10', '2018-09-14 18:33:10'),
(2, 'Google as spun content! WordAi\'s Brain Understands Concepts and Ideas', 'Before WordAi even starts spinning, it reads the entire article to understand both \"generally\" what the article is about and the \"specifics\" as to what exactly happens in the article. This allows WordAi to create complicated paragraph and document level spins based on its deep understanding of the article. Because no other machine has this level of deep understanding, it makes your content look human written. It is even able to correctly write high quality titles by identifying what the article is talking about.', '2018-09-14 18:33:32', '2018-09-14 18:33:32'),
(3, 'new post', 'fsdfsdfsd', '2018-09-14 20:03:55', '2018-09-14 20:03:55'),
(4, 'new post', 'dasdsad', '2018-09-24 19:35:54', '2018-09-24 19:35:54'),
(5, 'dasdasdasd', 'dsad', '2018-09-24 21:33:19', '2018-09-24 21:33:19'),
(6, 'mew two', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequatur blanditiis perferendis deleniti modi odit saepe adipisci quis accusantium esse, neque necessitatibus ex nulla optio unde eaque! Minus asperiores deserunt consectetur!', '2018-09-24 22:11:56', '2018-09-24 22:11:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
